% ManipulationDetector, CSI 660 Digital Image Forensics
% Matthew Frey & Darshan Shinde
% Detects inconsistencies in Texts and Fonts on Basis Of Planar Homography



X1 = [68,213,249,285,380,414,527];
Y1 = [24,21,20,26,24,24,24];

X2 = [69,113,140,235,284,360,400,464,538,599,624];
Y2 = [64,63,61,63,64,64,62,63,64,68,69];

p1 = polyfit(X1,Y1,1);   % p returns 2 coefficients fitting r = a_1 * x + a_2
r1 = p1(1) .* X1 + p1(2); % compute a new vector r that has matching datapoints in x

p2 = polyfit(X2,Y2,1);   % p returns 2 coefficients fitting r = a_1 * x + a_2
r2 = p2(1) .* X2 + p2(2); % compute a new vector r that has matching datapoints in x

img = imread('edit_airport2.jpg');
figure,imshow(img)

%# make sure the image doesn't disappear if we plot something else
hold on
% now plot both the points in y and the curve fit in r
plot(X1, Y1, 'x');
hold on;
plot(X1, r1, '-', 'color', 'yellow');

% now plot both the points in y and the curve fit in r
plot(X2, Y2, 'x');
hold on;
plot(X2, r2, '-', 'color', 'yellow');
hold off;