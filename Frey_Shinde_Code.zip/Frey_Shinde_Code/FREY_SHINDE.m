% ManipulationDetector, CSI 660 Digital Image Forensics
% Matthew Frey & Darshan Shinde
% Detects inconsistencies in Texts and Fonts on Basis Of Planar Homography



X1 = [32,175,215,267,499,519,617,649];
Y1 = [19,20,20,21,26,27,29,29];

X2 = [24,77,123,201,255,307,338,412,529,555,594,635,681,761];
Y2 = [63,65,66,67,68,70,70,71,74,74,71,73,76,77];

p1 = polyfit(X1,Y1,1);   % p returns 2 coefficients fitting r = a_1 * x + a_2
r1 = p1(1) .* X1 + p1(2); % compute a new vector r that has matching datapoints in x

p2 = polyfit(X2,Y2,1);   % p returns 2 coefficients fitting r = a_1 * x + a_2
r2 = p2(1) .* X2 + p2(2); % compute a new vector r that has matching datapoints in x

img = imread('edit_airport1.jpg');
figure,imshow(img)

%# make sure the image doesn't disappear if we plot something else
hold on
% now plot both the points in y and the curve fit in r
plot(X1, Y1, 'x');
hold on;
plot(X1, r1, '-', 'color', 'yellow');

% now plot both the points in y and the curve fit in r
plot(X2, Y2, 'x');
hold on;
plot(X2, r2, '-', 'color', 'yellow');
hold off;