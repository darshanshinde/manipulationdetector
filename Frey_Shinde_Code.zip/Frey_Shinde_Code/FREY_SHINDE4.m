% ManipulationDetector, CSI 660 Digital Image Forensics
% Matthew Frey & Darshan Shinde
% Detects inconsistencies in Texts and Fonts on Basis Of Planar Homography



X1 = [10,28];
Y1 = [30,28];


p1 = polyfit(X1,Y1,1);   % p returns 2 coefficients fitting r = a_1 * x + a_2
r1 = p1(1) .* X1 + p1(2); % compute a new vector r that has matching datapoints in x

img = imread('s1.jpg');
figure,imshow(img)

%# make sure the image doesn't disappear if we plot something else
hold on
% now plot both the points in y and the curve fit in r
plot(X1, Y1, 'x');
hold on;
plot(X1, r1, '-', 'color', 'yellow');

